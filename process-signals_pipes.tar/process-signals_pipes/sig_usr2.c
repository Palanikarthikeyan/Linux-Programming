#include "ab.h"
void f1(int signo){
	printf("Handler block\n");
}
int main(){
	int pid;
	signal(SIGUSR1,f1);
	printf("This is main process\n");
	pid=getpid();
	kill(pid,SIGUSR1);
	printf("Exit from main process\n");	
	return 0;
}

