#include "ab.h"

void abc(int i)
{
  printf("I=%d\n",i);
}

int main()
{
 if(signal(SIGINT,abc)==SIG_ERR)
 {
     printf("\n Can't Catch Signal\n");
 }
 
 while(1){
      sleep(1);
 }
}
