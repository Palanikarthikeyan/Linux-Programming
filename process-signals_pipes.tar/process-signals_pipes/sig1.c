#include "ab.h"

void signal_Handler(int signum)
{
 printf("Caught signal%d\n",signum);
}

int main()
{
 signal(SIGINT,signal_Handler);
 while(1)
 {
    printf("Program processing here..\n");
    sleep(5);
 }
 return 0;
}
