#include "ab.h"

int f1(int sno){
	printf("Handler block invoked\n");
	alarm(2); //scheduled a new alarm after 2 secs
}
int main(){
	signal(SIGALRM,f1);
	alarm(3); //scheduled alarm after 3 secs
	while(1){
		printf("process code\n");
		pause(); //waiting until signal is handled
		printf("Next section of code\n");
	}
	
	return 0;
}
