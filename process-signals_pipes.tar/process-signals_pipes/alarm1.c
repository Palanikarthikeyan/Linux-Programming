#include "ab.h"

int f1(int sno){
	printf("Handler block invoked\n");
}
int main(){
	signal(SIGALRM,f1);
	alarm(3); //scheduled alarm after 3 secs
	while(1){
		printf("process code\n");
		sleep(1);
	}
	
	return 0;
}
