 #include "ab.h"
 int main(){
  int pid1,pid2;
  pid1=fork();
  
  if(pid1 == 0){
	while(1){
		printf("pid1 is running\n");
		sleep(2);
	}
  }

  pid2=fork();
    
  if(pid2 == 0){
	while(1){
		printf("pid2 is running\n");
		sleep(2);
	}
  }
  sleep(3);
  kill(pid1,SIGSTOP); //suspend pid1-process
  sleep(3);
  kill(pid1,SIGCONT); //Resume pid1-process
  sleep(3);
  kill(pid2,SIGSTOP); //suspend pid1-process
  sleep(3);
  kill(pid2,SIGCONT); //Resume pid1-process
  sleep(1);
  kill(pid1,SIGINT);
  kill(pid2,SIGINT);
  return 0;
 }

