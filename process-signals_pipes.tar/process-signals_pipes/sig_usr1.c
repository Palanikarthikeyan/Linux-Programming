#include "ab.h"
void f1(int signo){
	printf("Handler block\n");
}
int main(){
	signal(SIGUSR1,f1);
	raise(SIGUSR1); // sending signal <signum> to calling process
	printf("Main code\n");
	return 0;
}

