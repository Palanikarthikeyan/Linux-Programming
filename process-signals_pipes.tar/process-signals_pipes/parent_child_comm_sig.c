//parent child communication with signals

#include "ab.h"
void handler_parent(int signo){
	printf("Parent - Received a response signal from child\n");
	printf("PID:%d\n",getpid());
}

void handler_child(int signo){
	printf("Child - Received a signal from parent\n");
	sleep(2);
	kill(getppid(),SIGUSR1);
}
int main(){
 pid_t pid;
 pid=fork();
 printf("PID=%d\n",pid);
 if(pid == 0){
	signal(SIGUSR1,handler_child);
	printf("Child - Waiting for signal\n");
	pause();
 }else{
	signal(SIGUSR1,handler_parent);
	sleep(1);
	printf("Parent-Sending signal to child\n");
	kill(pid,SIGUSR1);
	printf("Waiting for response\n");
	pause();
 }
	return 0;
}
