	
 #include "ab.h"
 #define READ 0
 #define WRITE 1
	  
 int main(){
	int fd[2];
	char var[20];
	int r;
	pipe(fd); //create an unnamed pipe

	if(fork()==0){  //Child - write operation
			
		//close(fd[READ]);
		write(fd[WRITE],"Message",15);
		printf("write operation is done:%d\n",getpid());
		//close(fd[WRITE]);
	}else{  //parent - read operation
		//close(fd[WRITE]);
		r=read(fd[READ],var,15); //receive
		printf("read operation is done - PID:=%d\n",getpid());
		//close(fd[READ]);
	}
    }
		
